<?php
	//CONEXAO COM BANCO DE DADOS
	$conn = new mysqli('localhost', 'root', '', 'matheus');
	$conexao = mysqli_query($conn, 'SET NAMES utf8');
?>

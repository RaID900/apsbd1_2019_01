<?php

	include "../conexao.php";

	$nome = $_POST['nome'];
	$username = $_POST['username'];
	$email = $_POST['email'];
	$senha = $_POST['senha'];

	$seleciona = "INSERT INTO cliente (nome,username,email,senha) VALUES('$nome','$username','$email','$senha') ";
	$res_seleciona = mysqli_query($conn, $seleciona);


	$seleciona = "SELECT MAX(id_cliente) FROM cliente";
	$res_seleciona = mysqli_query($conn, $seleciona);
	$consulta = mysqli_fetch_assoc($res_seleciona);
	$ultimoId = $consulta['MAX(id_cliente)'];

	header("Location:/profile.php?id_cliente=$ultimoId");












?>

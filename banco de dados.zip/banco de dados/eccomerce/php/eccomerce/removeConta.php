<?php

	include "../conexao.php";

	$id_cliente =  $_POST['id_cliente'];

	$seleciona = "DELETE FROM cliente WHERE id_cliente = $id_cliente";
	$res_seleciona = mysqli_query($conn, $seleciona);

 header("Location:/");

?>

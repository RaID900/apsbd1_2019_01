<?php

	include "../conexao.php";

	$id_cliente = $_POST['id_cliente'];
	$nome 			= $_POST['nome'];
	$username 	= $_POST['username'];
	$email 			= $_POST['email'];
	$senha 			= $_POST['senha'];
	$cep 			  = $_POST['cep'];
	$cidade 		= $_POST['cidade'];
	$bairro 		= $_POST['bairro'];
	$logradouro = $_POST['logradouro'];
	$numero 		= intval($_POST['numero']);

	$seleciona = "UPDATE cliente
								SET
								nome 			       = '$nome',
								username 	       = '$username',
								email 		       = '$email',
								senha 		       = '$senha',
								cep 			       = '$cep',
								cidade 		       = '$cidade',
								bairro 		   		 = '$bairro',
								logradouro       = '$logradouro',
								numeroImovel     = $numero
								WHERE id_cliente = $id_cliente";
	$res_seleciona = mysqli_query($conn, $seleciona);

	session_start();
	$_SESSION['update'] = true;

	header("Location:/profile.php?id_cliente=$id_cliente");

?>
